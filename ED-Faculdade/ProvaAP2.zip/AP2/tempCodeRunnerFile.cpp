

        if(aux == nullptr)
        {
            return 0